import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class CalculatorWithSetupTest {
    private Calculator calc;
    // Setup: runs before each test
    @Before
    public void setUp() {
        calc = new Calculator();
        System.out.println("Setup: Calculator instance created.");
    }
    // Teardown: runs after each test
    @After
    public void tearDown() {
        System.out.println("Teardown: Test completed.\n");
    }
    @Test
    public void testAddition() {
        int a = 4, b = 6;
        int result = calc.add(a, b);
        // Assert
        assertEquals(10, result);
    }
    @Test
    public void testSubtraction() {
        int a = 9, b = 3;
        int result = calc.subtract(a, b);
        // Assert
        assertEquals(6, result);
    }
}

