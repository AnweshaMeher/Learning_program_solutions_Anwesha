package org.mockito;

public interface ExternalApi {
	String getData();


}
