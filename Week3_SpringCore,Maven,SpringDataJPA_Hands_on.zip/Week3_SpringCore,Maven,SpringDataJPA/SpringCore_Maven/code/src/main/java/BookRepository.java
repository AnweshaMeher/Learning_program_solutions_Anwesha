
public class BookRepository {
	 public void saveBook(String book) {
	        System.out.println("Book saved: " + book);
	    }

}
