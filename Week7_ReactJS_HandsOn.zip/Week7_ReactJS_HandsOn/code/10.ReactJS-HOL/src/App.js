import React from 'react';
import './App.css';

const officeList = [
  {
    name: "Skyline Tower",
    rent: 75000,
    address: "MG Road, Bangalore",
    image: "https://www.sohopodomorocity.com/wp-content/uploads/2016/09/4.jpg"
  },
  {
    name: "Green Plaza",
    rent: 55000,
    address: "HSR Layout, Bangalore",
    image: "https://tse4.mm.bing.net/th/id/OIP.Q2ylHisUnojXVMEF7As4SAHaE8?pid=Api&P=0&h=180"
  },
  {
    name: "Tech Hub",
    rent: 60000,
    address: "Indiranagar, Bangalore",
    image: "https://officebanao.com/wp-content/uploads/2023/10/Modern-Offices_459-1024x684.jpg"
  }
];

function App() {
  return (
    <div className="App">
      <h1>Office Space Rental App</h1>

      {officeList.map((office, index) => (
        <div
          key={index}
          style={{
            border: "1px solid #ccc",
            margin: "10px",
            padding: "10px",
            borderRadius: "10px",
            width: "300px",
            marginLeft: "auto",
            marginRight: "auto"
          }}
        >
          <h2>{office.name}</h2>
          <img src={office.image} alt={office.name} className="office-image" />
          <p><strong>Address:</strong> {office.address}</p>
          <p style={{ color: office.rent > 60000 ? 'green' : 'red' }}>
            <strong>Rent:</strong> ₹{office.rent}
          </p>
        </div>
      ))}
    </div>
  );
}

export default App;
