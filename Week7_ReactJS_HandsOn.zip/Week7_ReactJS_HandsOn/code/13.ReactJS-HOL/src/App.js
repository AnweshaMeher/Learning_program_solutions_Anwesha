import React from 'react';
import './App.css';
import BookDetails from './BookDetails';
import CourseDetails from './CourseDetails';
import BlogDetails from './BlogDetails';
import { books, courses, blogs } from './data'; 

function App() {
  return (
    <div className="container">
      <div className="component-column">
        <CourseDetails courses={courses} />
      </div>
      <div className="component-column">
        <BookDetails books={books} />
      </div>
      <div className="component-column">
        <BlogDetails blogs={blogs} />
      </div>
    </div>
  );
}

export default App;