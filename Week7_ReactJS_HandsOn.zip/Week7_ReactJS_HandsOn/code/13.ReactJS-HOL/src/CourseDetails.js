import React from 'react';

function CourseDetails(props) {
  const courseList = props.courses.map((course) => (
    <div key={course.id} className="item">
      <h2>{course.name}</h2>
      <p>{course.date}</p>
    </div>
  ));
  return (
    <>
      <h1>Course Details</h1>
      {courseList}
    </>
  );
}

export default CourseDetails;