import React from 'react';

function BlogDetails(props) {
  const blogList = props.blogs.map((blog) => (
    <div key={blog.id} className="item">
      <h2>{blog.title}</h2>
      <p><strong>{blog.author}</strong></p>
      <p>{blog.content}</p>
    </div>
  ));
  return (
    <>
      <h1>Blog Details</h1>
      {blogList}
    </>
  );
}

export default BlogDetails;