import React from 'react';

function BookDetails(props) {
  // Using .map() to create the list of books [cite: 2]
  const bookList = props.books.map((book) => (
    <div key={book.id} className="item"> {/* Using a unique key is important [cite: 2] */}
      <h3>{book.bname}</h3>
      <p>{book.price}</p>
    </div>
  ));

  return (
    <>
      <h1>Book Details</h1>
      {bookList}
    </>
  );
}

export default BookDetails;