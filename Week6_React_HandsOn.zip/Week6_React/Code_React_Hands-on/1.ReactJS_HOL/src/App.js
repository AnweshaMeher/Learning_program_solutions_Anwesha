import logo from './logo.svg';
import './App.css';

function App() {
 return (
  <h1>Welcome to the first session of React</h1>
 );
}

export default App;
