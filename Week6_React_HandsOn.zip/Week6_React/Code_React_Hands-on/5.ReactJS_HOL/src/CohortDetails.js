import React from 'react';
import styles from './CohortDetails.module.css';

const CohortDetails = (props) => {
  const { cohort } = props;

  // Define the style for the h3 element based on cohort status
  const headerStyle = {
    color: cohort.status === 'Ongoing' ? 'green' : 'blue',
  };

  return (
    // Apply the 'box' style from the CSS module to the container div
    <div className={styles.box}>
      <h3 style={headerStyle}>
        {cohort.name} - {cohort.program}
      </h3>
      <dl>
        <dt>Started On</dt>
        <dd>{cohort.startedOn}</dd>

        <dt>Current Status</dt>
        <dd>{cohort.status}</dd>

        <dt>Coach</dt>
        <dd>{cohort.coach}</dd>

        <dt>Trainer</dt>
        <dd>{cohort.trainer}</dd>
      </dl>
    </div>
  );
};

export default CohortDetails;