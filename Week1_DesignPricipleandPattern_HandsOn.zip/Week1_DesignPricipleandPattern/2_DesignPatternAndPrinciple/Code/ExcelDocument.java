
public class ExcelDocument implements Document  {
	public void open() {
		System.out.println("Opening excel document");
	}

}
