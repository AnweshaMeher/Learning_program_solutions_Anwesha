
public class Forecast {
	public static double predictFutureValue(double currentValue, double rate, int years) {
        if (years == 0) return currentValue;
        return predictFutureValue(currentValue * (1 + rate), rate, years - 1);
    }

    public static void main(String[] args) {
        double currentValue = 10000;
        double growthRate = 0.10; 
        int years = 5;

        System.out.println("Recursive Forecast: Rs." + predictFutureValue(currentValue, growthRate, years));
    }

}
