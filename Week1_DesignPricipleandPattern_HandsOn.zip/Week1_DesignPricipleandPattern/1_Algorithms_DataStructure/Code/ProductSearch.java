//Exercise 2: E-commerce Platform Search Function
public class ProductSearch {
	public static int linearSearch(Product[] arr, String name) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].productName.equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(Product[] arr, String name) {
        int low = 0, high = arr.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            int cmp = arr[mid].productName.compareToIgnoreCase(name);
            if (cmp == 0) return mid;
            else if (cmp < 0) low = mid + 1;
            else high = mid - 1;
        }
        return -1;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Book", "Education"),
            new Product(2, "Camera", "Electronics"),
            new Product(3, "Laptop", "Electronics")
        };

        // For binary search, sort by productName
        java.util.Arrays.sort(products, (a, b) -> a.productName.compareToIgnoreCase(b.productName));

        System.out.println("Linear Search: " + linearSearch(products, "Camera"));
        System.out.println("Binary Search: " + binarySearch(products, "Laptop"));
    }
	

}
